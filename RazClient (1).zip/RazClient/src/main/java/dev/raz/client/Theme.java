package dev.raz.client;

public record Theme(String name, int accent, int panel, int header) {
    public static final Theme[] ALL = {
        new Theme("Anubis Blue", 0xFF3D9BFF, 0xE0101218, 0xF0181B24),
        new Theme("Violet",      0xFFB46CFF, 0xE0120F18, 0xF01B1524),
        new Theme("Crimson",     0xFFFF4D5E, 0xE0180F11, 0xF0241518),
        new Theme("Emerald",     0xFF3DDC84, 0xE00F1612, 0xF0151F19),
        new Theme("Gold",        0xFFFFC53D, 0xE0161410, 0xF0211E15),
    };
    public static Theme current = ALL[0];
}
