package dev.raz.client.modules;

import dev.raz.client.Module;
import dev.raz.client.Category;
import dev.raz.client.setting.NumSetting;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

public class AutoTotem extends Module {
    final NumSetting delay = add(new NumSetting("Delay", 0, 0, 10, 1));
    private int wait;

    public AutoTotem() { super("AutoTotem", "Keeps a totem in your offhand", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN); }

    @Override public void onTick() {
        var p = mc.player;
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING) || mc.currentScreen != null) { wait = delay.i(); return; }
        if (wait-- > 0) return;
        for (int i = 0; i < 36; i++) {
            if (!p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) continue;
            int slot = i < 9 ? i + 36 : i; // hotbar sits at 36..44 in the player screen handler
            mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
            wait = delay.i();
            return;
        }
    }
}
