package dev.raz.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public final class Util {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private Util() {}

    public static String keyName(int key) {
        if (key <= 0) return "NONE";
        switch (key) {
            case GLFW.GLFW_KEY_RIGHT_SHIFT: return "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_SHIFT: return "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return "RCTRL";
            case GLFW.GLFW_KEY_LEFT_ALT: return "LALT";
            case GLFW.GLFW_KEY_SPACE: return "SPACE";
        }
        String n = GLFW.glfwGetKeyName(key, 0);
        return n != null ? n.toUpperCase() : "K" + key;
    }

    /** Horizontal movement vector from WASD relative to yaw; zero if no input. */
    public static Vec3d moveDir(double speed) {
        var o = mc.options; var p = mc.player;
        double f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        double s = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
        if (f == 0 && s == 0) return Vec3d.ZERO;
        double len = Math.sqrt(f * f + s * s); f /= len; s /= len;
        double yaw = Math.toRadians(p.getYaw());
        return new Vec3d((-Math.sin(yaw) * f + Math.cos(yaw) * s) * speed, 0,
                          (Math.cos(yaw) * f + Math.sin(yaw) * s) * speed);
    }
}
