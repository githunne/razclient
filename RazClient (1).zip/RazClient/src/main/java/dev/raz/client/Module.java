package dev.raz.client;

import dev.raz.client.setting.Setting;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();
    public final String name, description; public final Category category;
    public int key; public final List<Setting> settings = new ArrayList<>();
    private boolean enabled;

    protected Module(String name, String description, Category category, int key) {
        this.name = name; this.description = description; this.category = category; this.key = key;
    }
    protected <S extends Setting> S add(S s) { settings.add(s); return s; }

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean v) { if (v != enabled) toggle(); }
    public void toggle() { enabled = !enabled; if (enabled) onEnable(); else onDisable(); }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick() {}
    public void onWorldRender(WorldRenderContext ctx) {}
}
