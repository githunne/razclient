package dev.raz.client.setting;

public class BoolSetting extends Setting {
    public boolean value;
    public BoolSetting(String name, boolean def) { super(name); value = def; }
    @Override public String save() { return Boolean.toString(value); }
    @Override public void load(String s) { value = Boolean.parseBoolean(s); }
}
