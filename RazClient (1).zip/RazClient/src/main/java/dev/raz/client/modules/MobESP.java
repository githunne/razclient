package dev.raz.client.modules;

import dev.raz.client.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import org.lwjgl.glfw.GLFW;

public class MobESP extends Module {
    public MobESP() { super("MobESP", "Outlines hostile mobs", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN); }
    @Override public void onTick() { for (Entity e : mc.world.getEntities()) if (e instanceof HostileEntity) e.setGlowing(true); }
    @Override protected void onDisable() { if (mc.world != null) for (Entity e : mc.world.getEntities()) if (e instanceof HostileEntity) e.setGlowing(false); }
}
