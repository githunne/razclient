package dev.raz.client.modules;

import dev.raz.client.*;
import org.lwjgl.glfw.GLFW;

public class Sprint extends Module {
    public Sprint() { super("Sprint", "Always sprint while moving forward", Category.MOVEMENT, GLFW.GLFW_KEY_V); }
    @Override public void onTick() {
        var p = mc.player;
        if (p.forwardSpeed > 0 && !p.horizontalCollision && !p.isSneaking()) p.setSprinting(true);
    }
}
