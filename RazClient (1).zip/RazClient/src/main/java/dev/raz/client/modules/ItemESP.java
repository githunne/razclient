package dev.raz.client.modules;

import dev.raz.client.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import org.lwjgl.glfw.GLFW;

public class ItemESP extends Module {
    public ItemESP() { super("ItemESP", "Outlines dropped items", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN); }
    @Override public void onTick() { for (Entity e : mc.world.getEntities()) if (e instanceof ItemEntity) e.setGlowing(true); }
    @Override protected void onDisable() { if (mc.world != null) for (Entity e : mc.world.getEntities()) if (e instanceof ItemEntity) e.setGlowing(false); }
}
