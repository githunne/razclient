package dev.raz.client.gui;

import dev.raz.client.*;
import dev.raz.client.setting.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.Click;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/**
 * Floating-panel GUI: draggable category panels, live search, per-module settings (right-click),
 * middle-click to bind, bottom tab bar (Modules / Friends / Themes / HUD / Settings).
 * FILL: input signatures below are the 1.21.9+ shape (Click / KeyInput / CharInput). Older versions use raw doubles/ints.
 */
public class ClickGui extends Screen {
    private enum Tab { MODULES("Modules"), FRIENDS("Friends"), THEMES("Themes"), HUD("HUD"), SETTINGS("Settings");
        final String label; Tab(String l) { label = l; } }
    private interface Action { void run(double mx, int button); }
    private record Hit(int x, int y, int w, int h, Action a) {
        boolean in(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }
    private static class Panel { final Category cat; int x, y; boolean open = true;
        Panel(Category c, int x, int y) { cat = c; this.x = x; this.y = y; } }

    private static final int W = 112, HH = 16, RH = 14, SH = 12;
    private final List<Panel> panels = new ArrayList<>();
    private final List<Hit> hits = new ArrayList<>();
    private final Set<Module> expanded = new HashSet<>();
    private Tab tab = Tab.MODULES;
    private String search = "", friendInput = "";
    private Module binding; private Panel dragging; private int dragDx, dragDy; private Action sliderDrag;

    public ClickGui() {
        super(Text.literal("RazClient"));
        int i = 0; for (Category c : Category.values()) panels.add(new Panel(c, 14 + i++ * (W + 8), 34));
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        hits.clear();
        Theme t = Theme.current;
        ctx.fill(0, 0, width, height, 0x88000000);
        switch (tab) {
            case MODULES -> renderModules(ctx, mx, my, t);
            case FRIENDS -> renderFriends(ctx, t);
            case THEMES -> renderThemes(ctx, t);
            case HUD -> renderHud(ctx, t);
            case SETTINGS -> renderSettings(ctx, t);
        }
        renderTabs(ctx, mx, my, t);
    }

    private void renderModules(DrawContext ctx, int mx, int my, Theme t) {
        int sw = 170, sx = (width - sw) / 2;
        ctx.fill(sx, 8, sx + sw, 24, t.header());
        ctx.fill(sx, 23, sx + sw, 24, t.accent());
        String shown = search.isEmpty() ? "Search modules..." : search + (System.currentTimeMillis() / 500 % 2 == 0 ? "_" : "");
        ctx.drawTextWithShadow(textRenderer, shown, sx + 6, 12, search.isEmpty() ? 0xFF777777 : 0xFFFFFFFF);

        String q = search.toLowerCase();
        for (Panel p : panels) {
            List<Module> ms = RazClient.modules.modules.stream()
                .filter(m -> m.category == p.cat && (q.isEmpty() || m.name.toLowerCase().contains(q))).toList();
            if (!q.isEmpty() && ms.isEmpty()) continue;
            ctx.fill(p.x, p.y, p.x + W, p.y + HH, t.header());
            ctx.fill(p.x, p.y + HH - 1, p.x + W, p.y + HH, t.accent());
            ctx.drawTextWithShadow(textRenderer, p.cat.label, p.x + 6, p.y + 4, 0xFFFFFFFF);
            ctx.drawTextWithShadow(textRenderer, p.open ? "-" : "+", p.x + W - 10, p.y + 4, 0xFF999999);
            final Panel fp = p;
            hits.add(new Hit(p.x, p.y, W, HH, (x, b) -> {
                if (b == 1) fp.open = !fp.open;
                else if (b == 0) { dragging = fp; dragDx = (int) x - fp.x; dragDy = (int) lastY - fp.y; }
            }));
            if (!p.open && q.isEmpty()) continue;
            int y = p.y + HH;
            for (Module m : ms) {
                boolean on = m.isEnabled(), hov = mx >= p.x && mx < p.x + W && my >= y && my < y + RH;
                ctx.fill(p.x, y, p.x + W, y + RH, hov ? 0xF0242834 : t.panel());
                if (on) ctx.fill(p.x, y, p.x + 2, y + RH, t.accent());
                int col = binding == m ? 0xFFFFC53D : on ? t.accent() : 0xFFCCCCCC;
                ctx.drawTextWithShadow(textRenderer, m.name, p.x + 6, y + 3, col);
                String kb = binding == m ? "[...]" : m.key > 0 ? "[" + Util.keyName(m.key) + "]" : "";
                ctx.drawTextWithShadow(textRenderer, kb, p.x + W - 4 - textRenderer.getWidth(kb), y + 3, 0xFF777777);
                final Module fm = m;
                hits.add(new Hit(p.x, y, W, RH, (x, b) -> {
                    if (b == 0) fm.toggle();
                    else if (b == 1 && !fm.settings.isEmpty()) { if (!expanded.remove(fm)) expanded.add(fm); }
                    else if (b == 2) binding = fm;
                }));
                y += RH;
                if (expanded.contains(m)) for (Setting s : m.settings) { y = renderSetting(ctx, p.x, y, s, t); }
            }
        }
    }

    private int renderSetting(DrawContext ctx, int x, int y, Setting s, Theme t) {
        ctx.fill(x, y, x + W, y + SH, 0xF00C0E13);
        if (s instanceof BoolSetting b) {
            ctx.drawTextWithShadow(textRenderer, s.name, x + 10, y + 2, 0xFFAAAAAA);
            String v = b.value ? "on" : "off";
            ctx.drawTextWithShadow(textRenderer, v, x + W - 6 - textRenderer.getWidth(v), y + 2, b.value ? t.accent() : 0xFF666666);
            hits.add(new Hit(x, y, W, SH, (mx, bt) -> b.value = !b.value));
        } else if (s instanceof NumSetting n) {
            ctx.fill(x + 6, y + SH - 3, x + 6 + (int) ((W - 12) * n.fraction()), y + SH - 1, t.accent());
            String v = n.step >= 1 ? "" + n.i() : String.format("%.1f", n.value);
            ctx.drawTextWithShadow(textRenderer, s.name, x + 10, y + 1, 0xFFAAAAAA);
            ctx.drawTextWithShadow(textRenderer, v, x + W - 6 - textRenderer.getWidth(v), y + 1, 0xFFDDDDDD);
            final int bx = x + 6, bw = W - 12;
            Action a = (mx, bt) -> n.setFromFraction((mx - bx) / bw);
            hits.add(new Hit(x, y, W, SH, (mx, bt) -> { a.run(mx, bt); sliderDrag = a; }));
        } else if (s instanceof ModeSetting m) {
            ctx.drawTextWithShadow(textRenderer, s.name, x + 10, y + 2, 0xFFAAAAAA);
            ctx.drawTextWithShadow(textRenderer, m.get(), x + W - 6 - textRenderer.getWidth(m.get()), y + 2, t.accent());
            hits.add(new Hit(x, y, W, SH, (mx, bt) -> m.cycle()));
        }
        return y + SH;
    }

    private void renderFriends(DrawContext ctx, Theme t) {
        int x = width / 2 - 90, y = 40;
        ctx.fill(x, y, x + 180, y + 16, t.header()); ctx.fill(x, y + 15, x + 180, y + 16, t.accent());
        String shown = friendInput.isEmpty() ? "Type a name, press Enter..." : friendInput + "_";
        ctx.drawTextWithShadow(textRenderer, shown, x + 6, y + 4, friendInput.isEmpty() ? 0xFF777777 : 0xFFFFFFFF);
        y += 20;
        for (String f : new ArrayList<>(Friends.list)) {
            ctx.fill(x, y, x + 180, y + RH, t.panel());
            ctx.drawTextWithShadow(textRenderer, f, x + 6, y + 3, 0xFF3DDC84);
            ctx.drawTextWithShadow(textRenderer, "remove", x + 180 - 8 - textRenderer.getWidth("remove"), y + 3, 0xFF777777);
            hits.add(new Hit(x, y, 180, RH, (mx, b) -> Friends.remove(f)));
            y += RH;
        }
    }

    private void renderThemes(DrawContext ctx, Theme t) {
        int x = width / 2 - 70, y = 40;
        for (Theme th : Theme.ALL) {
            ctx.fill(x, y, x + 140, y + 18, th.header()); ctx.fill(x, y, x + 4, y + 18, th.accent());
            ctx.drawTextWithShadow(textRenderer, th.name(), x + 10, y + 5, th == Theme.current ? th.accent() : 0xFFCCCCCC);
            hits.add(new Hit(x, y, 140, 18, (mx, b) -> Theme.current = th));
            y += 20;
        }
    }

    private void renderHud(DrawContext ctx, Theme t) {
        int x = width / 2 - 70, y = 40;
        y = toggleRow(ctx, t, x, y, "Watermark", Hud.watermark, () -> Hud.watermark = !Hud.watermark);
        y = toggleRow(ctx, t, x, y, "Module list", Hud.arraylist, () -> Hud.arraylist = !Hud.arraylist);
        y = toggleRow(ctx, t, x, y, "Coordinates", Hud.coords, () -> Hud.coords = !Hud.coords);
        toggleRow(ctx, t, x, y, "Radar", Hud.radar, () -> Hud.radar = !Hud.radar);
    }

    private void renderSettings(DrawContext ctx, Theme t) {
        int x = width / 2 - 70, y = 40;
        ctx.fill(x, y, x + 140, y + 18, t.header());
        ctx.drawTextWithShadow(textRenderer, "Save config now", x + 10, y + 5, t.accent());
        hits.add(new Hit(x, y, 140, 18, (mx, b) -> Config.save()));
        y += 20;
        ctx.fill(x, y, x + 140, y + 18, t.header());
        ctx.drawTextWithShadow(textRenderer, "Unbind all modules", x + 10, y + 5, 0xFFCCCCCC);
        hits.add(new Hit(x, y, 140, 18, (mx, b) -> RazClient.modules.modules.forEach(m -> m.key = 0)));
    }

    private int toggleRow(DrawContext ctx, Theme t, int x, int y, String label, boolean on, Runnable r) {
        ctx.fill(x, y, x + 140, y + 18, t.header());
        if (on) ctx.fill(x, y, x + 3, y + 18, t.accent());
        ctx.drawTextWithShadow(textRenderer, label, x + 10, y + 5, on ? t.accent() : 0xFFCCCCCC);
        hits.add(new Hit(x, y, 140, 18, (mx, b) -> r.run()));
        return y + 20;
    }

    private void renderTabs(DrawContext ctx, int mx, int my, Theme t) {
        int tw = 74, total = tw * Tab.values().length, x = (width - total) / 2, y = height - 22;
        ctx.fill(x - 4, y - 2, x + total + 4, y + 18, t.header());
        for (Tab tb : Tab.values()) {
            boolean sel = tb == tab;
            ctx.drawCenteredTextWithShadow(textRenderer, tb.label, x + tw / 2, y + 4, sel ? t.accent() : 0xFFAAAAAA);
            if (sel) ctx.fill(x + 8, y + 14, x + tw - 8, y + 15, t.accent());
            hits.add(new Hit(x, y, tw, 18, (m, b) -> { tab = tb; binding = null; }));
            x += tw;
        }
    }

    // ---- input ----
    private double lastY;

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y(); int b = click.button(); lastY = my;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.in(mx, my)) { h.a().run(mx, b); return true; }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (dragging != null) { dragging.x = (int) click.x() - dragDx; dragging.y = (int) click.y() - dragDy; return true; }
        if (sliderDrag != null) { sliderDrag.run(click.x(), 0); return true; }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) { dragging = null; sliderDrag = null; return super.mouseReleased(click); }

    @Override
    public boolean keyPressed(KeyInput in) {
        int key = in.key();
        if (binding != null) {
            binding.key = key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_BACKSPACE ? 0 : key;
            binding = null; return true;
        }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        if (tab == Tab.MODULES && key == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) { search = search.substring(0, search.length() - 1); return true; }
        if (tab == Tab.FRIENDS) {
            if (key == GLFW.GLFW_KEY_BACKSPACE && !friendInput.isEmpty()) { friendInput = friendInput.substring(0, friendInput.length() - 1); return true; }
            if (key == GLFW.GLFW_KEY_ENTER) { Friends.add(friendInput); friendInput = ""; return true; }
        }
        return super.keyPressed(in);
    }

    @Override
    public boolean charTyped(CharInput in) {
        String s = in.asString();
        if (binding != null) return true;
        if (tab == Tab.MODULES) { search += s; return true; }
        if (tab == Tab.FRIENDS && friendInput.length() < 16) { friendInput += s; return true; }
        return super.charTyped(in);
    }

    @Override public void close() { Config.save(); super.close(); }
}
