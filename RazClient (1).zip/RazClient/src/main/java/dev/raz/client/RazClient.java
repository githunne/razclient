package dev.raz.client;

import dev.raz.client.gui.ClickGui;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;

public class RazClient implements ClientModInitializer {
    public static ModuleManager modules;
    private static ClickGui gui;

    public static ClickGui gui() { if (gui == null) gui = new ClickGui(); return gui; }

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        Config.load();
        ClientTickEvents.END_CLIENT_TICK.register(modules::tick);
        // FILL: HudRenderCallback / WorldRenderEvents are deprecated or reshaped on newer Fabric API; swap to HudElementRegistry / the current world-render hook if needed
        HudRenderCallback.EVENT.register((ctx, tick) -> Hud.render(ctx));
        WorldRenderEvents.AFTER_ENTITIES.register(c -> {
            for (Module m : modules.modules) if (m.isEnabled()) m.onWorldRender(c);
        });
        Runtime.getRuntime().addShutdownHook(new Thread(Config::save));
    }
}
