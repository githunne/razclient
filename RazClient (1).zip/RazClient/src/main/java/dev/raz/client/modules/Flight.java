package dev.raz.client.modules;

import dev.raz.client.*;
import dev.raz.client.setting.NumSetting;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class Flight extends Module {
    final NumSetting speed = add(new NumSetting("Speed", 0.6, 0.1, 3, 0.1));
    public Flight() { super("Flight", "Fly with movement keys", Category.MOVEMENT, GLFW.GLFW_KEY_F); }
    @Override public void onTick() {
        var o = mc.options;
        double y = o.jumpKey.isPressed() ? speed.value : o.sneakKey.isPressed() ? -speed.value : 0;
        Vec3d h = Util.moveDir(speed.value);
        mc.player.setVelocity(h.x, y, h.z);
    }
}
