package dev.raz.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;

import java.util.Comparator;
import java.util.List;

public final class Hud {
    public static boolean watermark = true, arraylist = true, coords = true, radar = true;
    private Hud() {}

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null || mc.world == null) return;
        int accent = Theme.current.accent();
        var tr = mc.textRenderer;

        if (watermark) {
            ctx.fill(3, 3, 7 + tr.getWidth("RazClient") + 4, 15, Theme.current.header());
            ctx.fill(3, 3, 5, 15, accent);
            ctx.drawTextWithShadow(tr, "RazClient", 9, 5, accent);
        }
        if (arraylist) {
            List<Module> on = RazClient.modules.modules.stream().filter(Module::isEnabled)
                .sorted(Comparator.comparingInt((Module m) -> tr.getWidth(m.name)).reversed()).toList();
            int y = 3, w = ctx.getScaledWindowWidth();
            for (Module m : on) {
                int tw = tr.getWidth(m.name);
                ctx.fill(w - tw - 8, y, w - 2, y + 11, Theme.current.header());
                ctx.fill(w - 3, y, w - 1, y + 11, accent);
                ctx.drawTextWithShadow(tr, m.name, w - tw - 6, y + 2, accent);
                y += 11;
            }
        }
        if (coords) {
            String s = String.format("XYZ  %.1f  %.1f  %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
            ctx.drawTextWithShadow(tr, s, 4, ctx.getScaledWindowHeight() - 12, 0xFFDDDDDD);
        }
        if (radar) drawRadar(ctx, mc, 4, 22, 72);
    }

    private static void drawRadar(DrawContext ctx, MinecraftClient mc, int x, int y, int size) {
        ctx.fill(x, y, x + size, y + size, Theme.current.panel());
        int cx = x + size / 2, cy = y + size / 2;
        ctx.fill(x, cy, x + size, cy + 1, 0x30FFFFFF);
        ctx.fill(cx, y, cx + 1, y + size, 0x30FFFFFF);
        ctx.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFFFFFF);
        double range = 48, scale = (size / 2.0) / range, yaw = Math.toRadians(mc.player.getYaw());
        for (PlayerEntity t : mc.world.getPlayers()) {
            if (t == mc.player) continue;
            double dx = t.getX() - mc.player.getX(), dz = t.getZ() - mc.player.getZ();
            double sx = -dx * Math.cos(yaw) - dz * Math.sin(yaw);
            double sy = -dx * Math.sin(yaw) + dz * Math.cos(yaw);
            int px = (int) (cx + sx * scale), py = (int) (cy - sy * scale);
            if (px < x + 1 || px > x + size - 2 || py < y + 1 || py > y + size - 2) continue;
            int c = Friends.is(t.getName().getString()) ? 0xFF3DDC84 : 0xFFFF4D5E;
            ctx.fill(px - 1, py - 1, px + 2, py + 2, c);
        }
    }
}
