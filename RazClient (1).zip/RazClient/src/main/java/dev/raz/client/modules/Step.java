package dev.raz.client.modules;

import dev.raz.client.*;
import dev.raz.client.setting.NumSetting;
import net.minecraft.entity.attribute.EntityAttributes;
import org.lwjgl.glfw.GLFW;

public class Step extends Module {
    final NumSetting height = add(new NumSetting("Height", 1.0, 0.6, 2.5, 0.1));
    public Step() { super("Step", "Walk up blocks without jumping", Category.MOVEMENT, GLFW.GLFW_KEY_UNKNOWN); }
    @Override public void onTick() {
        var a = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (a != null) a.setBaseValue(height.value);
    }
    @Override protected void onDisable() {
        if (mc.player == null) return;
        var a = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (a != null) a.setBaseValue(0.6);
    }
}
