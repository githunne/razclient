package dev.raz.client.modules;

import dev.raz.client.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class TriggerBot extends Module {
    public TriggerBot() { super("TriggerBot", "Attacks the player under your crosshair", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN); }

    @Override public void onTick() {
        if (mc.currentScreen != null || mc.player.getAttackCooldownProgress(0f) < 1f) return;
        if (mc.targetedEntity instanceof PlayerEntity t && !Friends.is(t.getName().getString())) {
            mc.interactionManager.attackEntity(mc.player, t);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }
}
