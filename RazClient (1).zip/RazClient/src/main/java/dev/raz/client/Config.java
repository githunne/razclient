package dev.raz.client;

import dev.raz.client.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.Path;
import java.util.Properties;

public final class Config {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("razclient.properties");
    private Config() {}

    public static void save() {
        Properties p = new Properties();
        for (Module m : RazClient.modules.modules) {
            p.setProperty("m." + m.name + ".on", Boolean.toString(m.isEnabled()));
            p.setProperty("m." + m.name + ".key", Integer.toString(m.key));
            for (Setting s : m.settings) p.setProperty("m." + m.name + "." + s.name, s.save());
        }
        p.setProperty("friends", String.join(",", Friends.list));
        p.setProperty("theme", Theme.current.name());
        p.setProperty("hud.watermark", "" + Hud.watermark); p.setProperty("hud.arraylist", "" + Hud.arraylist);
        p.setProperty("hud.coords", "" + Hud.coords);       p.setProperty("hud.radar", "" + Hud.radar);
        try (OutputStream o = new FileOutputStream(FILE.toFile())) { p.store(o, "RazClient"); } catch (IOException ignored) {}
    }

    public static void load() {
        if (!FILE.toFile().exists()) return;
        Properties p = new Properties();
        try (InputStream i = new FileInputStream(FILE.toFile())) { p.load(i); } catch (IOException e) { return; }
        for (Module m : RazClient.modules.modules) {
            try { m.key = Integer.parseInt(p.getProperty("m." + m.name + ".key", "" + m.key)); } catch (Exception ignored) {}
            for (Setting s : m.settings) { String v = p.getProperty("m." + m.name + "." + s.name); if (v != null) s.load(v); }
            // modules start disabled; re-enable at runtime once a world is loaded
        }
        String f = p.getProperty("friends", "");
        for (String n : f.split(",")) Friends.add(n);
        for (Theme t : Theme.ALL) if (t.name().equals(p.getProperty("theme"))) Theme.current = t;
        Hud.watermark = Boolean.parseBoolean(p.getProperty("hud.watermark", "true"));
        Hud.arraylist = Boolean.parseBoolean(p.getProperty("hud.arraylist", "true"));
        Hud.coords = Boolean.parseBoolean(p.getProperty("hud.coords", "true"));
        Hud.radar = Boolean.parseBoolean(p.getProperty("hud.radar", "true"));
    }
}
