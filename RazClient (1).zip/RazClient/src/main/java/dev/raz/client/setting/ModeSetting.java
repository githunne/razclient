package dev.raz.client.setting;

import java.util.Arrays;

public class ModeSetting extends Setting {
    public final String[] modes; public int index;
    public ModeSetting(String name, String def, String... modes) {
        super(name); this.modes = modes; index = Math.max(0, Arrays.asList(modes).indexOf(def));
    }
    public String get() { return modes[index]; }
    public boolean is(String m) { return get().equals(m); }
    public void cycle() { index = (index + 1) % modes.length; }
    @Override public String save() { return get(); }
    @Override public void load(String s) { int i = Arrays.asList(modes).indexOf(s); if (i >= 0) index = i; }
}
