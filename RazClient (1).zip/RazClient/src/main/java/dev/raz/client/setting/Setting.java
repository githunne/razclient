package dev.raz.client.setting;

public abstract class Setting {
    public final String name;
    protected Setting(String name) { this.name = name; }
    public abstract String save();
    public abstract void load(String s);
}
