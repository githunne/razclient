package dev.raz.client.modules;

import dev.raz.client.*;
import dev.raz.client.setting.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class KillAura extends Module {
    final NumSetting range = add(new NumSetting("Range", 3.2, 2, 6, 0.1));
    final BoolSetting players = add(new BoolSetting("Players", true));
    final BoolSetting mobs = add(new BoolSetting("Mobs", false));
    final ModeSetting sort = add(new ModeSetting("Sort", "Distance", "Distance", "Health"));

    public KillAura() { super("KillAura", "Attacks nearby targets on cooldown", Category.COMBAT, GLFW.GLFW_KEY_R); }

    @Override public void onTick() {
        var p = mc.player;
        if (p.getAttackCooldownProgress(0f) < 1f) return;
        LivingEntity best = null; double bs = Double.MAX_VALUE, r2 = range.value * range.value;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive()) continue;
            boolean ok = (players.value && e instanceof PlayerEntity pe && !Friends.is(pe.getName().getString()))
                      || (mobs.value && e instanceof HostileEntity);
            if (!ok) continue;
            double d = p.squaredDistanceTo(e);
            if (d > r2) continue;
            double score = sort.is("Health") ? le.getHealth() : d;
            if (score < bs) { bs = score; best = le; }
        }
        if (best == null) return;
        mc.interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
    }
}
