package dev.raz.client.modules;

import dev.raz.client.*;
import net.minecraft.entity.player.PlayerEntity;
import org.lwjgl.glfw.GLFW;

public class PlayerESP extends Module {
    public PlayerESP() { super("PlayerESP", "Outlines players through walls", Category.RENDER, GLFW.GLFW_KEY_G); }
    @Override public void onTick() { for (PlayerEntity p : mc.world.getPlayers()) if (p != mc.player) p.setGlowing(true); }
    @Override protected void onDisable() { if (mc.world != null) for (PlayerEntity p : mc.world.getPlayers()) p.setGlowing(false); }
}
