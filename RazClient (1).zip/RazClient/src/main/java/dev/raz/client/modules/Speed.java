package dev.raz.client.modules;

import dev.raz.client.*;
import dev.raz.client.setting.NumSetting;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class Speed extends Module {
    final NumSetting speed = add(new NumSetting("Speed", 0.35, 0.1, 1.5, 0.05));
    public Speed() { super("Speed", "Faster ground movement", Category.MOVEMENT, GLFW.GLFW_KEY_UNKNOWN); }
    @Override public void onTick() {
        if (!mc.player.isOnGround()) return;
        Vec3d h = Util.moveDir(speed.value);
        if (h == Vec3d.ZERO) return;
        mc.player.setVelocity(h.x, mc.player.getVelocity().y, h.z);
    }
}
