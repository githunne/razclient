package dev.raz.client;

import dev.raz.client.gui.ClickGui;
import dev.raz.client.modules.*;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.*;

public class ModuleManager {
    public final List<Module> modules = new ArrayList<>();
    private final boolean[] down = new boolean[GLFW.GLFW_KEY_LAST + 1];

    public ModuleManager() {
        modules.addAll(List.of(
            new KillAura(), new TriggerBot(), new AutoTotem(), new CrystalAura(),
            new Sprint(), new Flight(), new Speed(), new Step(), new NoFall(),
            new PlayerESP(), new MobESP(), new ItemESP(), new StorageESP(), new Fullbright(),
            new AutoDrop()
        ));
    }

    public void tick(MinecraftClient mc) {
        if (mc.getWindow() == null) return;
        long h = mc.getWindow().getHandle();
        if (mc.currentScreen == null) {
            poll(h, GLFW.GLFW_KEY_RIGHT_SHIFT, () -> mc.setScreen(RazClient.gui()));
            for (Module m : modules) if (m.key > 0 && m.key < down.length) poll(h, m.key, m::toggle);
        }
        if (mc.player == null || mc.world == null) return;
        for (Module m : modules) if (m.isEnabled()) m.onTick();
    }

    private void poll(long h, int key, Runnable r) {
        boolean now = GLFW.glfwGetKey(h, key) == GLFW.GLFW_PRESS;
        if (now && !down[key]) r.run();
        down[key] = now;
    }
}
