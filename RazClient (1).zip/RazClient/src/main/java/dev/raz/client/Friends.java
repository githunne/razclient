package dev.raz.client;

import java.util.*;

public final class Friends {
    public static final Set<String> list = new LinkedHashSet<>();
    private Friends() {}
    public static boolean is(String name) { return list.stream().anyMatch(f -> f.equalsIgnoreCase(name)); }
    public static void add(String n) { if (!n.isBlank()) list.add(n.trim()); }
    public static void remove(String n) { list.removeIf(f -> f.equalsIgnoreCase(n)); }
}
