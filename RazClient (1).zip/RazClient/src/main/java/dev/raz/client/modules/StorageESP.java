package dev.raz.client.modules;

import dev.raz.client.*;
import dev.raz.client.setting.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.entity.*;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.glfw.GLFW;

public class StorageESP extends Module {
    final NumSetting chunks = add(new NumSetting("Chunk radius", 6, 1, 12, 1));
    final BoolSetting spawners = add(new BoolSetting("Spawners", true));
    final BoolSetting chests = add(new BoolSetting("Chests", true));
    final BoolSetting shulkers = add(new BoolSetting("Shulkers", true));

    public StorageESP() { super("StorageESP", "Boxes storage blocks and spawners", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN); }

    /*
     * FILL: RenderLayer.getLines() is depth-tested, so boxes hide behind terrain. For true see-through
     * rendering register a custom RenderLayer / pipeline with depth test off (the render API changed in
     * 1.21.5+ and again after, so wire it against the version you build for).
     */
    @Override public void onWorldRender(WorldRenderContext ctx) {
        if (ctx.consumers() == null || ctx.matrixStack() == null) return;
        var cam = ctx.camera().getPos();
        MatrixStack ms = ctx.matrixStack();
        VertexConsumer vc = ctx.consumers().getBuffer(RenderLayer.getLines());
        int cx = mc.player.getChunkPos().x, cz = mc.player.getChunkPos().z, r = chunks.i();
        ms.push(); ms.translate(-cam.x, -cam.y, -cam.z);
        for (int x = cx - r; x <= cx + r; x++) for (int z = cz - r; z <= cz + r; z++) {
            if (!(mc.world.getChunk(x, z, ChunkStatus.FULL, false) instanceof WorldChunk c)) continue;
            for (BlockEntity be : c.getBlockEntities().values()) {
                float[] col = null;
                if (spawners.value && be instanceof MobSpawnerBlockEntity) col = new float[]{1f, 0.3f, 0.3f};
                else if (chests.value && (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || be instanceof EnderChestBlockEntity)) col = new float[]{1f, 0.77f, 0.24f};
                else if (shulkers.value && be instanceof ShulkerBoxBlockEntity) col = new float[]{0.7f, 0.42f, 1f};
                if (col == null) continue;
                VertexRendering.drawBox(ms, vc, new Box(be.getPos()), col[0], col[1], col[2], 1f);
            }
        }
        ms.pop();
    }
}
