package dev.raz.client.modules;

import dev.raz.client.*;
import dev.raz.client.setting.NumSetting;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

import java.util.Set;

public class AutoDrop extends Module {
    private static final Set<Item> JUNK = Set.of(Items.COBBLESTONE, Items.DIRT, Items.NETHERRACK, Items.ROTTEN_FLESH,
        Items.COBBLED_DEEPSLATE, Items.GRAVEL, Items.ANDESITE, Items.DIORITE, Items.GRANITE, Items.SPIDER_EYE, Items.POISONOUS_POTATO);
    final NumSetting delay = add(new NumSetting("Delay (ticks)", 2, 0, 20, 1));
    private int cd;

    public AutoDrop() { super("AutoDrop", "Drops junk items from your inventory", Category.PLAYER, GLFW.GLFW_KEY_UNKNOWN); }

    @Override public void onTick() {
        if (mc.currentScreen != null || cd-- > 0) return;
        var p = mc.player;
        for (int i = 0; i < 36; i++) {
            if (!JUNK.contains(p.getInventory().getStack(i).getItem())) continue;
            int slot = i < 9 ? i + 36 : i;
            mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 1, SlotActionType.THROW, p);
            cd = delay.i(); return;
        }
    }
}
