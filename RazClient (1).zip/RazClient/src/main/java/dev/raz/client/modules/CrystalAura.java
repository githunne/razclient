package dev.raz.client.modules;

import dev.raz.client.*;
import dev.raz.client.setting.*;
import net.minecraft.block.Blocks;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class CrystalAura extends Module {
    final NumSetting breakRange = add(new NumSetting("Break range", 4.5, 2, 6, 0.1));
    final NumSetting placeRange = add(new NumSetting("Place range", 4.5, 2, 6, 0.1));
    final NumSetting targetRange = add(new NumSetting("Target range", 10, 4, 16, 1));
    final NumSetting delay = add(new NumSetting("Delay (ticks)", 2, 0, 10, 1));
    final BoolSetting place = add(new BoolSetting("Place", true));
    final BoolSetting breakC = add(new BoolSetting("Break", true));
    private int cd;

    public CrystalAura() { super("CrystalAura", "Places and breaks end crystals near targets", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN); }

    @Override public void onTick() {
        var p = mc.player;
        if (cd-- > 0) return;
        if (breakC.value) {
            for (EndCrystalEntity c : mc.world.getEntitiesByClass(EndCrystalEntity.class,
                    p.getBoundingBox().expand(breakRange.value), e -> true)) {
                if (p.squaredDistanceTo(c) > breakRange.value * breakRange.value) continue;
                mc.interactionManager.attackEntity(p, c);
                p.swingHand(Hand.MAIN_HAND);
                cd = delay.i(); return;
            }
        }
        if (!place.value) return;
        Hand hand = p.getOffHandStack().isOf(Items.END_CRYSTAL) ? Hand.OFF_HAND
                  : p.getMainHandStack().isOf(Items.END_CRYSTAL) ? Hand.MAIN_HAND : null;
        if (hand == null) return;
        PlayerEntity target = null; double bd = targetRange.value * targetRange.value;
        for (PlayerEntity t : mc.world.getPlayers()) {
            if (t == p || !t.isAlive() || Friends.is(t.getName().getString())) continue;
            double d = p.squaredDistanceTo(t);
            if (d < bd) { bd = d; target = t; }
        }
        if (target == null) return;
        BlockPos base = null; double best = Double.MAX_VALUE; int r = (int) Math.ceil(placeRange.value);
        BlockPos o = p.getBlockPos();
        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
            BlockPos b = o.add(x, y, z);
            var s = mc.world.getBlockState(b);
            if (!s.isOf(Blocks.OBSIDIAN) && !s.isOf(Blocks.BEDROCK)) continue;
            if (!mc.world.isAir(b.up()) || !mc.world.isAir(b.up(2))) continue;
            if (p.getEyePos().squaredDistanceTo(Vec3d.ofCenter(b)) > placeRange.value * placeRange.value) continue;
            if (!mc.world.getOtherEntities(null, new Box(b.up())).isEmpty()) continue;
            double d = target.squaredDistanceTo(Vec3d.ofCenter(b.up()));
            if (d < best) { best = d; base = b; }
        }
        if (base == null) return;
        mc.interactionManager.interactBlock(p, hand,
            new BlockHitResult(Vec3d.ofCenter(base).add(0, 0.5, 0), Direction.UP, base, false));
        p.swingHand(hand);
        cd = delay.i();
    }
}
