package dev.raz.client.setting;

public class NumSetting extends Setting {
    public double value; public final double min, max, step;
    public NumSetting(String name, double def, double min, double max, double step) {
        super(name); value = def; this.min = min; this.max = max; this.step = step;
    }
    public void setFromFraction(double f) {
        f = Math.max(0, Math.min(1, f));
        double v = min + (max - min) * f;
        value = Math.max(min, Math.min(max, Math.round(v / step) * step));
    }
    public double fraction() { return (value - min) / (max - min); }
    public float f() { return (float) value; }
    public int i() { return (int) Math.round(value); }
    @Override public String save() { return Double.toString(value); }
    @Override public void load(String s) { try { value = Double.parseDouble(s); } catch (Exception ignored) {} }
}
